import React, { Component } from 'react';
//class section 
class Home extends Component{
    //render method - to display the output 
    render(){
        return(
        <div>
            <h1>Home Pages</h1>
            <h3>WELL COME  TO REACT PROJECT</h3>  
        </div>
        )
    }
}
//export section  -- component is ready to be reused in another files 
export default Home;


